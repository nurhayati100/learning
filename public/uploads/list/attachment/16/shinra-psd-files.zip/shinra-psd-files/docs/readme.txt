
README FILE

________________________________________

Author
Luis Zuno

Thanks for Downloading!
This resource is free for personal and commercial use no attribution necessary. You are not allowed to redistribute this file on a different site. 

Note. I don't offer support on free files but you can post your questions to the community at http://luiszuno.com/free-forums/

LICENCE
http://creativecommons.org/licenses/by/3.0/

CONTENTS
This download package contains the following psd files:
blog.psdmain.psdportfolio.psdsingle-portfolio.psd

Visit my site for more free content at:
http://www.luiszuno.com

________________________________________

www.luiszuno.com
luis@luiszuno.com
Twitter @ansimuz

